"""CSC111 Project 1: Text Adventure Game

Instructions (READ THIS FIRST!)
===============================

This Python module contains the code for Project 1. Please consult
the project handout for instructions and details.

Copyright and Usage Information
===============================

This file is provided solely for the personal and private use of students
taking CSC111 at the University of Toronto St. George campus. All forms of
distribution of this code, whether as given or with any changes, are
expressly prohibited. For more information on copyright for CSC111 materials,
please consult our Course Syllabus.

This file is Copyright (c) 2024 CSC111 Teaching Team
"""

# Note: You may add in other import statements here as needed
from game_data import World, Player, available_actions, deposit, pickup, go

# Note: You may add helper functions, classes, etc. here as needed

# Note: You may modify the code below as needed; the following starter template are just suggestions
if __name__ == "__main__":

    import doctest

    doctest.testmod(verbose=True)

    # When you are ready to check your work with python_ta, uncomment the following lines.
    # (In PyCharm, select the lines below and press Ctrl/Cmd + / to toggle comments.)
    # You can use "Run file in Python Console" to run both pytest and PythonTA,
    # and then also test your methods manually in the console.
    import python_ta

    python_ta.check_all(config={
        'max-line-length': 120
    })
    with open("map.txt") as ma:
        with open("locations.txt") as loc:
            with open("items.txt") as it:
                w = World(ma, loc, it)
                p = Player(0, 0)

                # def print_format(sentences: str) -> None:
                #     """convert a str into several lines for better formating"""
                #     i = 0
                #     lines = len(sentences) // 80
                #     lst = []
                #     while i < lines:
                #         lst.append(sentences[i * 80: i * 80 + 80])
                #         i += 1
                #     if len(sentences) // 80 != len(sentences) / 80:
                #         lst.append(sentences[i * 80:])
                #     for line in lst:
                #         print(line)

                menu = ["look", "inventory", "score", "quit", "pickup", "deposit", "go"]
                # we changed the menu(pickup , deposit) deleted "back"
                location = w.get_location(p.x, p.y)
                print(location.long_desc)
                while not p.victory:
                    location = w.get_location(p.x, p.y)
                    # Depending on whether or not it's been visited before,
                    # print either full description (first time visit) or brief description (every subsequent visit)
                    for item in p.inventory:
                        if item.name == "tcard":
                            if item.swipes == 1:
                                print("Warning: you only have 1 swipe left on your tcard, please renew your swipes")

                    print("What to do? \n")
                    print("[menu]")
                    for action in available_actions(p, w).split(','):
                        print(action)
                    choice = input("\nEnter action: ")

                    if choice == "[menu]":
                        print("Menu Options: \n")
                        for option in menu:
                            print(option)
                        choice = input("\nChoose action: ")

                    elif choice == "look":
                        print(location.long_desc)

                    elif choice == "inventory":
                        for item in p.inventory:
                            print(item.name)

                    elif choice == "score":
                        print(p.score)

                    elif choice == "quit":
                        break

                    elif choice == "go":
                        direction = input("\n Choose a direction")
                        go(p, w, direction)
                        location = w.get_location(p.x, p.y)
                        if location.visit is False:
                            print(location.long_desc)
                            location.visit = True
                        else:
                            print(location.br_desc)

                    elif choice == "pickup":
                        thing_to_pickup = input(
                            "\n what do you want to pick up?")
                        pickup(p, thing_to_pickup, w)

                    elif choice == "deposit":
                        thing_to_deposit = input(
                            "\n what do you want to deposit? you can only deposit one thing at a time")
                        deposit(p, thing_to_deposit, w)
                    else:
                        print('your action is not available')
                    if p.steps > 10:
                        print('Danger! You are runnning out of steps. Now only 10 steps left.')

                    if p.steps > 30:
                        print('Sorry, you run out of steps and miss your exam')
                        break

                    if (any(['lucky_pen' == thing.name for thing in p.inventory])
                            and any(['cheat_sheet' == thing.name for thing in p.inventory])
                            and any(['lucky_pen' == thing.name for thing in p.inventory])
                            and w.get_location(p.x, p.y).number == 12 and p.steps < 41):
                        print(f'yayyy you win!! your score is {(40 - p.steps) * 4}')

                        p.victory = True

        #  REMEMBER: the location = w.get_location(p.x, p.y) at the top of this loop will update the location if
        #  the choice the player made was just a movement, so only updating player's position is enough to change the
        #  location to the next appropriate location
        #  Possibilities:
        #  A helper function such as do_action(w, p, location, choice)
        #  OR A method in World class w.do_action(p, location, choice)
        #  OR Check what type of action it is, then modify only player or location accordingly
        #  OR Method in Player class for move or updating inventory
        #  OR Method in Location class for updating location item info, or other location data etc....
